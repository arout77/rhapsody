-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Mar 28, 2022 at 11:37 AM
-- Server version: 5.6.41-84.1
-- PHP Version: 7.3.32

SET FOREIGN_KEY_CHECKS=0;
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `arout77_rhapsody`
--

-- --------------------------------------------------------

--
-- Table structure for table `clients`
--

CREATE TABLE `clients` (
  `cid` smallint(6) NOT NULL COMMENT 'This is not used within the application; just an auto inc field. Use client_id to send to clients for access',
  `client_id` varchar(32) COLLATE utf8_unicode_ci NOT NULL COMMENT 'MD5 hash of company''s name. This must be given to clients immediately upon registration, and is a required field to login',
  `name` varchar(75) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `clients`
--

INSERT INTO `clients` (`cid`, `client_id`, `name`) VALUES
(1, '91832e6a2065eed0ef5f54b97d5c7310', 'Space X'),
(2, '140864078aeca1c7c35b4beb33c53c34', 'Microsoft'),
(3, 'ec035be38510b4079cc82c591e3b5147', 'World Championship Wrestling'),
(5, '9f6290f4436e5a2351f12e03b6433c3c', 'Apple'),
(7, 'fe8dbaecbafdef6106b55d546f4a501d', 'National Basketball Association');

-- --------------------------------------------------------

--
-- Stand-in structure for view `compiled_ticket_data`
-- (See below for the actual view)
--
CREATE TABLE `compiled_ticket_data` (
`ticket_id` int(10) unsigned
,`date_submitted` timestamp
,`client_id` varchar(32)
,`client_name` varchar(75)
,`submitted_by` varchar(75)
,`role` enum('visitor','client','employee','admin')
,`status` enum('unassigned','assigned','in progress','on hold','complete')
,`assigned_to` mediumint(7) unsigned
,`first_response_due` int(11)
,`first_response_sent` int(11)
,`due_date` timestamp
,`date_completed` timestamp
,`priority` enum('low','normal','high','critical')
,`user_id` mediumint(7) unsigned
,`permissions` enum('visitor','client','employee','admin')
,`company` varchar(75)
,`full_name` varchar(75)
,`eid` mediumint(7) unsigned
,`employee_name` varchar(75)
,`employee_permissions` enum('visitor','client','employee','admin')
);

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE `employees` (
  `eid` mediumint(7) UNSIGNED NOT NULL,
  `name` varchar(75) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `company` varchar(75) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `permissions` enum('visitor','client','employee','admin') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'employee',
  `avatar` varchar(65) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`eid`, `name`, `email`, `company`, `password`, `date_created`, `permissions`, `avatar`) VALUES
(3, 'Andrew Rout', 'arout@diamondphp.org', 'Rhapsody Task Management', '$2y$10$rkXa4blDKuwdlBCbrODqB.4oIpoy3Tko2OmRAbgVy72WsYVfSDfkG', '2022-03-17 07:29:43', 'admin', 'andrew_rout.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `online`
--

CREATE TABLE `online` (
  `email` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `last_login` int(11) NOT NULL,
  `last_ping` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

CREATE TABLE `permissions` (
  `uid` mediumint(7) UNSIGNED NOT NULL,
  `name` varchar(75) COLLATE utf8_unicode_ci NOT NULL,
  `level` enum('visitor','client','employee','admin') COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `permissions`
--

INSERT INTO `permissions` (`uid`, `name`, `level`) VALUES
(3, 'Andrew Rout', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `session_data`
--

CREATE TABLE `session_data` (
  `session_id` varchar(32) NOT NULL DEFAULT '',
  `hash` varchar(32) NOT NULL DEFAULT '',
  `session_data` blob NOT NULL,
  `session_expire` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `signup_confirm`
--

CREATE TABLE `signup_confirm` (
  `id` int(10) NOT NULL,
  `email` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `code` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `is_confirmed` tinyint(1) NOT NULL DEFAULT '0',
  `date_confirmed` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tickets`
--

CREATE TABLE `tickets` (
  `tid` int(10) UNSIGNED NOT NULL COMMENT 'Ticket ID is simply a Unix timestamp at time of creation',
  `date_submitted` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `for_client_id` varchar(32) COLLATE utf8_unicode_ci NOT NULL COMMENT 'The client that ticket belongs to',
  `for_client_name` varchar(75) COLLATE utf8_unicode_ci NOT NULL,
  `submitted_by` varchar(75) COLLATE utf8_unicode_ci NOT NULL,
  `submit_by_auth` enum('visitor','client','employee','admin') COLLATE utf8_unicode_ci NOT NULL COMMENT 'This column is needed by `compiled_ticket_data` view to determine if a client or employee created the ticket',
  `status` enum('unassigned','assigned','in progress','on hold','complete') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'unassigned',
  `assigned_to` mediumint(7) UNSIGNED DEFAULT NULL,
  `first_response_due` int(11) NOT NULL,
  `first_response_sent` int(11) NOT NULL,
  `due_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_completed` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `priority` enum('low','normal','high','critical') COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tickets`
--

INSERT INTO `tickets` (`tid`, `date_submitted`, `for_client_id`, `for_client_name`, `submitted_by`, `submit_by_auth`, `status`, `assigned_to`, `first_response_due`, `first_response_sent`, `due_date`, `date_completed`, `priority`) VALUES
(1646847072, '2022-03-09 17:57:22', '91832e6a2065eed0ef5f54b97d5c7310', 'Space X', 'Elon Musk', 'client', 'assigned', 3, 1646848152, 0, '2022-03-16 18:19:44', '0000-00-00 00:00:00', 'low'),
(1646888595, '2022-03-15 17:18:12', '91832e6a2065eed0ef5f54b97d5c7310', 'Space X', 'Elon Musk', 'client', 'in progress', 3, 1646889675, 0, '2022-03-18 18:19:20', '0000-00-00 00:00:00', 'normal'),
(1646890000, '2022-03-15 17:18:12', '140864078aeca1c7c35b4beb33c53c34', 'Microsoft', 'Andrew Rout', 'admin', 'on hold', 3, 1646891080, 0, '2022-03-22 17:18:12', '0000-00-00 00:00:00', 'high');

-- --------------------------------------------------------

--
-- Table structure for table `timesheets`
--

CREATE TABLE `timesheets` (
  `timesheet_id` int(11) UNSIGNED NOT NULL COMMENT 'Just an autoincrement ID',
  `ticket_id` int(10) UNSIGNED NOT NULL COMMENT 'FK referencing tid in tickets table',
  `employee_name` varchar(75) COLLATE utf8_unicode_ci NOT NULL,
  `employee_id` mediumint(7) UNSIGNED NOT NULL,
  `hours` decimal(4,2) NOT NULL,
  `entry_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `timesheets`
--

INSERT INTO `timesheets` (`timesheet_id`, `ticket_id`, `employee_name`, `employee_id`, `hours`, `entry_date`) VALUES
(1, 1646847072, 'Andrew Rout', 3, 6.08, '2022-03-17'),
(2, 1646847072, 'Andrew Rout', 3, 2.47, '2022-03-09'),
(3, 1646847072, 'Andrew Rout', 3, 5.45, '2022-03-16'),
(4, 1646847072, 'Andrew Rout', 3, 8.00, '2022-03-02'),
(5, 1646888595, 'Andrew Rout', 3, 5.50, '2022-03-16'),
(6, 1646890000, 'Andrew Rout', 3, 6.62, '2022-03-18');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `uid` mediumint(7) UNSIGNED NOT NULL,
  `name` varchar(75) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `company` varchar(75) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `permissions` enum('visitor','client','employee','admin') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'client',
  `avatar` varchar(65) COLLATE utf8_unicode_ci DEFAULT NULL,
  `confirmed` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`uid`, `name`, `email`, `company`, `password`, `date_created`, `permissions`, `avatar`, `confirmed`) VALUES
(1, 'Elon Musk', 'muskie@spacex.com', 'Space X', '$2y$10$rUqOmqWGG0JjEt6IE0COuervwPB4KMPENVp0jrHMiEVEOzpNHFPgC', '2022-03-09 16:56:43', 'client', 'elon_musk.jpg', 1),
(2, 'Bill Gates', 'bjigga@ms.com', 'Microsoft', '$2y$10$rUqOmqWGG0JjEt6IE0COuervwPB4KMPENVp0jrHMiEVEOzpNHFPgC', '2022-03-11 03:49:41', 'client', NULL, 0),
(3, 'Lex Luger', 'flexylexy@wcw.com', 'World Championship Wrestling', '$2y$10$rUqOmqWGG0JjEt6IE0COuervwPB4KMPENVp0jrHMiEVEOzpNHFPgC', '2022-03-12 03:53:22', 'client', NULL, 0),
(4, 'Steve Jobs', 'sjobs@apple.com', 'Apple', '$2y$10$rUqOmqWGG0JjEt6IE0COuervwPB4KMPENVp0jrHMiEVEOzpNHFPgC', '2022-03-12 06:30:37', 'client', NULL, 0),
(5, 'Larry Bird', 'lbird@nba.com', 'National Basketball Association', '$2y$10$cFHV/PmmNX5tLWGeMDsgJuDqWrFzn9SBTYzmjHORYUJSyUz9Llem6', '2022-03-12 23:40:00', 'client', NULL, 0);

-- --------------------------------------------------------

--
-- Structure for view `compiled_ticket_data`
--
DROP TABLE IF EXISTS `compiled_ticket_data`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `compiled_ticket_data`  AS SELECT `t`.`tid` AS `ticket_id`, `t`.`date_submitted` AS `date_submitted`, `t`.`for_client_id` AS `client_id`, `t`.`for_client_name` AS `client_name`, `t`.`submitted_by` AS `submitted_by`, `t`.`submit_by_auth` AS `role`, `t`.`status` AS `status`, `t`.`assigned_to` AS `assigned_to`, `t`.`first_response_due` AS `first_response_due`, `t`.`first_response_sent` AS `first_response_sent`, `t`.`due_date` AS `due_date`, `t`.`date_completed` AS `date_completed`, `t`.`priority` AS `priority`, `u`.`uid` AS `user_id`, `u`.`permissions` AS `permissions`, `u`.`company` AS `company`, `u`.`name` AS `full_name`, `e`.`eid` AS `eid`, `e`.`name` AS `employee_name`, `e`.`permissions` AS `employee_permissions` FROM (((`tickets` `t` join `clients` `c` on((`t`.`for_client_id` = `c`.`client_id`))) join `users` `u` on((`t`.`for_client_name` = `u`.`company`))) join `employees` `e` on((`t`.`assigned_to` = `e`.`eid`))) ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `clients`
--
ALTER TABLE `clients`
  ADD PRIMARY KEY (`cid`),
  ADD UNIQUE KEY `client ID` (`client_id`),
  ADD UNIQUE KEY `idx_clients_client_id` (`client_id`),
  ADD UNIQUE KEY `idx_clients_name` (`name`),
  ADD KEY `name` (`name`);

--
-- Indexes for table `employees`
--
ALTER TABLE `employees`
  ADD PRIMARY KEY (`eid`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `company` (`company`),
  ADD KEY `name` (`name`);

--
-- Indexes for table `online`
--
ALTER TABLE `online`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`uid`),
  ADD KEY `name` (`name`,`level`);

--
-- Indexes for table `session_data`
--
ALTER TABLE `session_data`
  ADD PRIMARY KEY (`session_id`);

--
-- Indexes for table `signup_confirm`
--
ALTER TABLE `signup_confirm`
  ADD PRIMARY KEY (`id`),
  ADD KEY `confirmemail` (`email`);

--
-- Indexes for table `tickets`
--
ALTER TABLE `tickets`
  ADD PRIMARY KEY (`tid`),
  ADD KEY `name` (`submitted_by`),
  ADD KEY `due_date` (`due_date`),
  ADD KEY `first_response_due` (`first_response_due`),
  ADD KEY `priority` (`priority`),
  ADD KEY `assigned_to` (`assigned_to`),
  ADD KEY `submit_by_auth` (`submit_by_auth`),
  ADD KEY `client_id` (`for_client_id`);

--
-- Indexes for table `timesheets`
--
ALTER TABLE `timesheets`
  ADD PRIMARY KEY (`timesheet_id`),
  ADD KEY `ticket_id` (`ticket_id`),
  ADD KEY `timesheet_employee_name` (`employee_name`),
  ADD KEY `employee_id` (`employee_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`uid`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `avatar_UNIQUE` (`avatar`),
  ADD KEY `company` (`company`),
  ADD KEY `name` (`name`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `clients`
--
ALTER TABLE `clients`
  MODIFY `cid` smallint(6) NOT NULL AUTO_INCREMENT COMMENT 'This is not used within the application; just an auto inc field. Use client_id to send to clients for access', AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `employees`
--
ALTER TABLE `employees`
  MODIFY `eid` mediumint(7) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `signup_confirm`
--
ALTER TABLE `signup_confirm`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `timesheets`
--
ALTER TABLE `timesheets`
  MODIFY `timesheet_id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'Just an autoincrement ID', AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `uid` mediumint(7) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=65;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `clients`
--
ALTER TABLE `clients`
  ADD CONSTRAINT `client_name` FOREIGN KEY (`name`) REFERENCES `users` (`company`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `permissions`
--
ALTER TABLE `permissions`
  ADD CONSTRAINT `perm_employee_names` FOREIGN KEY (`name`) REFERENCES `employees` (`name`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `signup_confirm`
--
ALTER TABLE `signup_confirm`
  ADD CONSTRAINT `confirmemail` FOREIGN KEY (`email`) REFERENCES `users` (`email`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tickets`
--
ALTER TABLE `tickets`
  ADD CONSTRAINT `client_id` FOREIGN KEY (`for_client_id`) REFERENCES `clients` (`client_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `employee_id` FOREIGN KEY (`assigned_to`) REFERENCES `employees` (`eid`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `timesheets`
--
ALTER TABLE `timesheets`
  ADD CONSTRAINT `emp_id` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`eid`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `timesheet_employee_name` FOREIGN KEY (`employee_name`) REFERENCES `employees` (`name`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `timesheets_ibfk_1` FOREIGN KEY (`ticket_id`) REFERENCES `tickets` (`tid`) ON DELETE CASCADE ON UPDATE CASCADE;
SET FOREIGN_KEY_CHECKS=1;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
